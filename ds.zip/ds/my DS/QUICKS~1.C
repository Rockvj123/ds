#include<stdio.h>
#include<conio.h>
void quicksort(int[25],int,int);
void main()
{
  int i,n,a[25];
  clrscr();
  printf("\t\t\t\t\***Quick Sort***\t\t\t\t\n");
  printf("Enter The Number Of Elements :");
  scanf("%d",&n);
  printf("Enter %d Elements: \n",n);
  for(i=0;i<n;i++)
    scanf("%d",&a[i]);
  quicksort(a,0,n-1);
  printf("Sorted Elements :\n");
  for(i=0;i<n;i++)
    printf("%d\n",a[i]);
  getch();
}
void quicksort(int a[25],int l,int r)
{
  int i,j,pivot,temp;
  if(l<r)
  {
    pivot=l;
    i=l;
    j=r;
    while(i<j)
    {
      while(a[i]<=a[pivot] && i<=r)
	i++;
      while(a[j]>a[pivot] && i>=l)
	j--;
      if(i<j)
      {
	temp=a[i];
	a[i]=a[j];
	a[j]=temp;
      }
    }
    temp=a[pivot];
    a[pivot]=a[j];
    a[j]=temp;
    quicksort(a,l,j-1);
    quicksort(a,j+1,r);
  }
}