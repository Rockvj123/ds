#include<stdio.h>
#include<conio.h>
void main()
{
  int i,j,n,a[25],temp,pos;
  clrscr();
  printf("\t\t\t\t***Selection Sort***\t\t\t\t\n");
  printf("Enter The Number Of Elements :");
  scanf("%d",&n);
  printf("Enter %d Elements: \n",n);
  for(i=0;i<n;i++)
    scanf("%d",&a[i]);
  for(i=0;i<n-1;i++)
  {
    pos=i;
    for(j=i+1;j<n;j++)
    {
      if(a[pos]>a[j])
      pos=j;
    }
    temp=a[pos];
    a[pos]=a[i];
    a[i]=temp;
  }
  printf("Sorted Elements :\n");
  for(i=0;i<n;i++)
    printf("%d\n",a[i]);
  getch();
}