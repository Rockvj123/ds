#include<stdio.h>
#include<conio.h>
#define max 10
int queue[max];
int front=-1;
int rear=-1;
void ins();
void del();
void dis();
void main()
{
   int ch,item;
   clrscr();
   printf("\t\t :) Circular Queue Implementation using Array :(\n");
   do{
   printf("\n*** Circular Queue Operation ***\n 1.Insert\n 2.Delete\n 3.Display\n 4.Exit\n");
   printf("---Enter your choice---:");
   scanf("%d",&ch);
   switch(ch)
   {
     case 1:
       printf("Enter the element:");
       scanf("%d",&item);
       ins(item);break;
     case 2:del();break;
     case 3:dis();break;
     case 4:exit(0);
     default:printf("!Invalid choice!");}
   }while(ch!=4);
   getch();
}
void ins(int a)
{
   if((front==0 && rear==max-1)||(front==rear+1))
   {
     printf("\n! Queue is Overflow !");
     return;
   }
   if(front==-1)
   {
     front=0;
     rear=0;
   }
   else
   {
     if(rear==max-1)
     {
       rear=0;
     }
     else
     {
       rear=rear+1;
     }
   }
   queue[rear]=a;
}
void del()
{
   if(front==-1)
   {
     printf("! Queue is Underflow !\n");
     return;
   }
   if(front==rear)
   {
     int x;
     x=queue[front];
     printf("Deleted element is:%d\n",x);
     front=-1;
     rear=-1;
   }
   else
   {
     int x;
     if(front==max-1)
     {
       x=queue[front];
       printf("Deleted element:%d\n",x);
       front=0;
     }
     else
     {
       x=queue[front];
       printf("Deleted element:%d\n",x);
       front=front+1;
     }
   }
}
void dis()
{
   int frontpos=front,rearpos=rear;
   if(front==-1)
   {
     printf("! Queue is empty ! ");
   }
   if(frontpos<=rearpos)
   {
     while(frontpos<=rearpos)
     {
       printf("%d\n",queue[frontpos]);
       frontpos++;
     }
   }
   else
   {
     while(frontpos<=max-1)
     {
       printf("%d\n",queue[frontpos]);
       frontpos++;
     }
     frontpos=0;
     while(frontpos<=rearpos)
     {
       printf("%d\n",queue[frontpos]);
       frontpos++;
     }
   }
}