#include<stdio.h>
#include<conio.h>
struct node
{
  int data;
  struct node*next;
};

void print(struct node*tail)
{
  struct node*ptr=tail->next;
  do{
    printf("%d\n",ptr->data);
    ptr=ptr->next;
  }while(ptr!=tail->next);
}

void addend(struct node*tail,int data,int pos)
{
  struct node*temp=malloc(sizeof(struct node));
  temp->data=data;
  temp->next=tail->next;
  tail->next=temp;

  tail=tail->next;
  print(tail);
}


void addpos(struct node*tail,int data,int pos)
{
  int i;
  struct node*temp=malloc(sizeof(struct node));
  struct node*ptr=tail->next;
  temp->data=data;
  if(pos==1)
  {
    temp->next=tail->next;
    tail->next=temp;
    print(tail);
    return;
  }
  for(i=1;i<pos-1;i++)
  {
    ptr=ptr->next;
  }
  temp->next=ptr->next;
  ptr->next=temp;
  print(tail);
}

void main()
{
  int data,pos;
  struct node*tail=malloc(sizeof(struct node));
  struct node*first=malloc(sizeof(struct node));
  struct node*second=malloc(sizeof(struct node));
  struct node*ptr=tail->next;
  clrscr();
  tail->data=30;
  tail->next=first;
  first->data=10;
  first->next=second;
  second->data=20;
  second->next=tail;
  printf("---ADD AN ELEMENT IN CIRCULAR LINKED LIST---\n");
  print(tail);
  printf("Enter the element:");
  scanf("%d",&data);
  printf("Enter the position:");
  scanf("%d",&pos);
  if(pos>4){
    addend(tail,data,pos);
  }else{
    addpos(tail,data,pos);
  }
  getch();
}