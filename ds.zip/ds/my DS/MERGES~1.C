#include<stdio.h>
#include<conio.h>
void merge(int array[],int low,int mid,int high)
{
  int temp[50];
  int i=low;
  int j=mid+1;
  int k=low;
  while((i<=mid) && (j<=high))
  {
    if(array[i]<=array[j])
      temp[k++]=array[i++];
    else
      temp[k++]=array[j++];
  }
  while(i<=mid)
    temp[k++]=array[i++];
  while(j<=high)
    temp[k++]=array[j++];
  for(i=low;i<=high;i++)
    array[i]=temp[i];
}
void merge_sort(int array[],int low,int high)
{
  int mid;
  if(low!=high)
  {
    mid=(low+high)/2;
    merge_sort(array,low,mid);
    merge_sort(array,mid+1,high);
    merge(array,low,mid,high);
  }
}
void main()
{
  int i,n,array[50];
  clrscr();
  printf("\t\t\t\t***Merge Sort***\t\t\t\t\n");
  printf("Enter The Number Of Elements : ");
  scanf("%d",&n);
  printf("Enter %d Elements :",n);
  for(i=0;i<n;i++)
    scanf("%d",&array[i]);
  merge_sort(array,0,n-1);
  printf("Sorted List Is :\n");
  for(i=0;i<n;i++)
    printf("%d\n",array[i]);
  getch();
}