#include<stdio.h>
#include<conio.h>
struct node
{
  int data;
  struct node*next;
};

void print(struct node*tail)
{
  struct node*ptr=tail->next;
  do{
    printf("%d\n",ptr->data);
    ptr=ptr->next;
  }while(ptr!=tail->next);
}

void delpos(struct node*tail,int pos)
{
  int i;
  struct node*ptr=tail->next;
  struct node*temp;
  if(pos==0)
  {
    temp=ptr->next;
    tail->next=temp;
    print(tail);
    return;
  }
  for(i=0;i<pos-1;i++)
  {
    ptr=ptr->next;
    if(ptr==tail)
    {
      printf("Invalid\n");
      break;
    }
  }
  if(ptr!=tail)
  {
    temp=ptr->next;
    ptr->next=temp->next;
    print(tail);
  }
}
void main()
{
  int pos;
  struct node*tail=malloc(sizeof(struct node));
  struct node*first=malloc(sizeof(struct node));
  struct node*second=malloc(sizeof(struct node));
  clrscr();
  tail->data=30;
  tail->next=first;
  first->data=10;
  first->next=second;
  second->data=20;
  second->next=tail;
  printf("---DELETE AN ELEMENT FROM CIRCULAR LINKED LIST---\n");
  print(tail);
  printf("Enter the position to delete:");
  scanf("%d",&pos);
  delpos(tail,pos);
  getch();
}