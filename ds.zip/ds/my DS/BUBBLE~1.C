#include<stdio.h>
#include<conio.h>
void main()
{
  int a[50],n,i,j,temp;
  clrscr();
  printf("\t\t\t\t***Bubble Sort***\t\t\t\t\\n");
  printf("Enter The Number Of Elements :");
  scanf("%d",&n);
  printf("Enter The Elements One By One :\n");
  for(i=0;i<n;i++)
    scanf("%d",&a[i]);
  for(i=0;i<n;i++)
  {
    for(j=0;j<n-1;j++)
    {
      if(a[j]>=a[j+1])
      {
	temp=a[j];
	a[j]=a[j+1];
	a[j+1]=temp;
      }
    }
  }
  printf("Sorted Elements Is :\n");
  for(i=0;i<n;i++)
    printf("%d\n",a[i]);
  getch();
}