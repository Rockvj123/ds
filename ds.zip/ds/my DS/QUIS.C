#include<stdio.h>
#include<conio.h>
void quicksort(int[25],int,int);
void main()
{
  int i,n,a[25];
  clrscr();
  printf("Enter the No.of Elements:");
  scanf("%d",&n);
  printf("Enter %d Elements:\n",n);
  for(i=0;i<n;i++)
    scanf("%d",&a[i]);
  quicksort(a,0,n-1);
  printf("Sorted Elements\n");
  for(i=0;i<n;i++)
  {
    printf("%d\n",a[i]);
  }
  getch();
}
void quicksort(int a[25],int l,int r)
{
  int i,j,temp,pivot;
  if(l<r)
  {
    pivot=l;
    i=1;
    j=r;
    while(i<j)
    {
      while(a[i]<=a[pivot]  && i<=r)
      i++;
      while(a[j]>a[pivot] && j>=l)
      j--;
      if(i<j)
      {
	temp=a[i];
	a[i]=a[j];
	a[j]=temp;
      }
    }
      temp=a[pivot];
      a[pivot]=a[j];
      a[j]=temp;
      quicksort(a,l,j-1);
      quicksort(a,j+1,r);
  }
}
