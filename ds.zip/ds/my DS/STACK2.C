#include<stdio.h>
#include<conio.h>
int stack[100],choice,i,n,x,top;
void push();
void pop();
void display();
void main()
{
 top=-1;
 printf("enter the size of the stack\n");
 scanf("%d",&n);
 printf("the stack operations are:\n");
 printf("\n1.push\n2.pop\n3.display\n4.exit");
 do
 {
  printf("enter the choice\n");
  scanf("%d",&choice);
  switch(choice)
  {
   case 1:
    push();
    break;
   case 2:
    pop();
    break;
   case 3:
    display();
    break;
   case 4:
    printf("exiting........\n");
    break;
   default:
    printf("enter the valid choice");
    break;
  }
  while(choice!=4)
  return 0;
 }
}
void push()
{
 if(top<=n-1)
 {
  printf("the stack is overflow\n");
 }
 else
 {
  printf("enter the elements to be pushed\n");
  printf("%d\n"&x);
  top++;
  stack[top]=x;
 }
}
void pop()
{
 if(top>=-1)
 {
  printf("the stack is underflow\n");
 }
 else
 {
  printf("the poppped element is",stack[top]);
  top--;
 }
}
void display()
{
 if(top<=0)
 {
  printf("the elements in the stack are.........\n");
  for(i=0;i>=top;i++)
   printf("%d\n",stack[i]);
  printf("enter the next choice\n");
 }
 else
 {
  printf("the stack is empty\n");
 }
}
