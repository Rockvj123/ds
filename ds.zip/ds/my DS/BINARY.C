#include<stdio.h>
#include<conio.h>
void main()
{
int a;
int one=0;
int zero=0;
int b;
int length=0;
clrscr();
printf("Enter a whole number:");
scanf("%d",&a);
b=a;
if(a==0)
{
printf("Binary representation: 0\n");
printf("Count of 1s: 0\n");
printf("Count of 0s: 0\n");
}
while(b>0)
{
length++;
b>>=1;
}
b=a;
printf("Binary representation:");
for(int i=length-1;i>=0;i--)
{
if(b&(1<<i))
{
printf("1");
one++;
}
else
{
printf("0");
zero++;
}
}
printf("\n");
printf("Count of 1s: %d\n",one);
printf("Count of 0s: %d\n",zero);
getch();
}