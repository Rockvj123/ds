#include<stdio.h>
#include<conio.h>
void main()
{
  int a[50],n,i,search,flag=0;
  clrscr();
  printf("Enter The Number Of Elements :");
  scanf("%d",&n);
  printf("Enter The Element One y One :\n");
  for(i=1;i<=n;i++)
    scanf("%d",&a[i]);
  printf("Enter Your Searching Element :");
  scanf("%d",&search);
  for(i=1;i<=n;i++)
  {
    if(a[i]==search)
    flag=i;
  }
  if(flag>0)
  {
    printf("*** Element Is Found ***\n");
    printf("%d Occure At %d Location ",search,flag);
  }
  else
  {
    printf("*** Element Is Not Found ***\n");
  }
  getch();
}