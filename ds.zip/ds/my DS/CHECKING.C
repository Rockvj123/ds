#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void check_parentheses(char* code)
{
int i;
int len=strlen(code);
char* stack=calloc(len,sizeof(char));
int top=-1;
for(int i=0;i<len;i++)
{
if(code[i]=='(')
{
stack[++top]='(';
}
else if(code[i]==')')
{
if(top==-1)
{
printf("Unwanted close parenthesis\n");
return;
}
top--;
}
}
if(top!=-1)
{
printf("Unmatched open parentheses\n");
}
else
{
pritf("parentheses are balanced \n");
}
free(stack);
}
int main()
{
char* code="Your code here";
check_parentheses(code);
return 0;
}


