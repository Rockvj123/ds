#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
int pre(char c)
{
   if(c=='A')
      return 3;
   else if(c=='/'||c=='*')
      return 2;
   else if(c=='+'||c=='-')
      return 1;
   else
      return -1;
}
void intopost(char s[])
{
   char res[100];
   int resindex=0;
   char stack[100];
   int stackindex=-1;
   int len=strlen(s);
   int i=0;
   for(i=0;i<len;i++)
   {
     char c=s[i];
     if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9'))
     {
	res[resindex++]=c;
     }
     else if(c=='(')
     {
	stack[++stackindex]=c;
     }
     else if(c==')')
     {
	while(stackindex>=0 && stack[stackindex]!=')')
	{
	   res[resindex++]=stack[stackindex--];
	}
	stackindex--;
     }
     else
     {
	while(stackindex>=0 && pre(s[i])<pre(stack[stackindex])||pre(s[i])==pre(stack[stackindex]))
	{
	   res[resindex++]=stack[stackindex--];
	}
	stack[++stackindex]=c;
     }
   }
   while(stackindex>=0)
   {
      res[resindex++]=stack[stackindex--];
   }
   res[resindex]='\0';
   printf("%s",res);
}
void main()
{
   char exp[]="a+b*c";
   clrscr();
   intopost(exp);
   getch();
}