#include<stdio.h>
#include<conio.h>
#include<string.h>
#define Max 100
char stack[100];
int top=-1;
void push(char val)
{
   if(top==Max-1)
   {
     printf("Stack Overflow");
   }
   else
   {
     top++;
     stack[top]=val;
   }
}
void pop()
{
   int item;
   if(top==-1)
   {
     printf("Stack Underflow");
   }
   else
   {
     top--;
   }
}
int ispair(char val1,char val2)
{
   return((val1=='(' && val2==')')||(val1=='{' && val2=='}')||(val1=='[' && val2==']'));
}
int check(char exp[],int len)
{
   int i;
   for(i=0;i<len;i++)
   {
     if(exp[i]=='('||exp[i]=='{'||exp[i]=='[')
     {
       push(exp[i]);
     }
     else if((exp[i]==')'||exp[i]=='}'||exp[i]==']'))
     {
       if(top==-1)
       {
	 return 0;
       }
       else if(ispair(stack[top],exp[i]))
       {
	 pop();
       }
       else
       {
	 return 0;
       }
     }
   }
   return top==-1;
}
void main()
{
   char st[]="{[()]}";
   clrscr();
   if(check(st,strlen(st)))
   {
     printf("Balanced");
   }
   else
   {
     printf("Unbalanced");
   }
   getch();
}


