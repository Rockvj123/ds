#include<stdio.h>
#include<conio.h>
#define Max 100
int stack[Max];
int top=-1;
void push(int item)
{
   if(top>=Max-1)
   {
     printf("Stack Overflow\n");
     return;
   }
   top++;
   stack[top]=item;
}
int pop()
{
   int item;
   if(top<0)
   {
     printf("Stack Underflow\n");
     return -1;
   }
   item=stack[top];
   top--;
   return item;
}
int isoper(char symbol)
{
   if(symbol=='+'||symbol=='-'||symbol=='*'||symbol=='/')
   {
      return 1;
   }
   return 0;
}
int evaluate(char expression[])
{
   int i=0;
   char symbol=expression[i];
   int op1,op2,result;
   while(symbol!='\0')
   {
      if(symbol>='0'&&symbol<='9')
      {
	int num=symbol-'0';
	push(num);
      }
      else if(isoper(symbol))
      {
	op2=pop();
	op1=pop();
	switch(symbol)
	{
	  case'+':{result=op1+op2;break;}
	  case'-':{result=op1-op2;break;}
	  case'*':{result=op1*op2;break;}
	  case'/':{result=op1/op2;break;}
	}
	push(result);
     }
     i++;
     symbol=expression[i];
   }
   result=pop();
   return result;
}
void main()
{
   char expression[]="567+*8-";
   int result=evaluate(expression);
   clrscr();
   printf("Result=%d\n",result);
   getch();
}
