#include<stdio.h>
#include<conio.h>
void main()
{
  int a[50],n,i,search,first,last,mid;
  clrscr();
  printf("Enter The Number Of Elements :");
  scanf("%d",&n);
  printf("Enter The Elements One By One :\n");
  for(i=1;i<=n;i++)
    scanf("%d",&a[i]);
  printf("Enter The Element To Search :");
  scanf("%d",&search);
  first=0;
  last=n-1;
  mid=(first+last)/2;
  while(first<=last)
  {
    if(a[mid]==search)
    {
      printf("*** Element Found At %d Loaction ***",mid);
      break;
    }
    else if(a[mid]<search)
    {
      first=mid+1;
    }
    else
    {
      last=mid-1;
      mid=(first+last)/2;
    }
    if(first>last)
    {
      printf("*** Element Is Not Found ***");
    }

  }
  getch();
}