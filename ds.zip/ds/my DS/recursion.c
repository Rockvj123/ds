#include <stdio.h>

void func(int n,int m)
{
    if(n>0)
    {
        func(--n,++m);
        printf("%d %d",n,m);
        func(--n,++m);
    }
}
int main() {
    int i=3,j=2;
    func(i,j);    
    return 0;
}