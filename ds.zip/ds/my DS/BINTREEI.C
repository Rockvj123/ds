#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node*newnode(int item);
struct node
{
  int key;
  struct node*left,*right;
};
void inorder(struct node*root)
{
  if(root!=NULL)
  {
    inorder(root->left);
    printf("%d\t",root->key);
    inorder(root->right);
  }
}
struct node*insert(struct node*node,int key)
{
  if(node==NULL)
    return newnode(key);
  if(key<node->key)
    node->left=insert(node->left,key);
  if(key>node->key)
    node->right=insert(node->right,key);
  return node;
}
struct node*newnode(int item)
{
  struct node*temp=malloc(sizeof(struct node));
  temp->key=item;
  return temp;
}
void main()
{
  int i,n,ele;
  struct node*root=NULL;
  clrscr();
  printf("\t\t\t***Binary Search Tree Insertion***\n");
  printf("---Enter the Number of Node:---\n");
  scanf("%d",&n);
  printf("Enter %d Elements one by one:\n",n);
  for(i=0;i<n;i++)
  {
    scanf("%d",&ele);
    root=insert(root,ele);
  }
  inorder(root);
  getch();
}