#include<stdio.h>
#include<conio.h>
void main()
{
  int i,j,n,a[25],temp;
  clrscr();
  printf("\t\t\t\t***Insertion Sort***\t\t\t\t\n");
  printf("Enter The Number Of Elements :");
  scanf("%d",&n);
  printf("Enter %d Elements: \n",n);
  for(i=0;i<n;i++)
    scanf("%d",&a[i]);
  for(i=1;i<n;i++)
  {
    temp=a[i];
    j=i-1;
    while(temp<=a[j] && j>=0)
    {
      a[j+1]=a[j];
      j=j-1;
    }
    a[j+1]=temp;
  }
  printf("Sorted Elements :\n");
  for(i=0;i<n;i++)
    printf("%d\n",a[i]);
  getch();
}
