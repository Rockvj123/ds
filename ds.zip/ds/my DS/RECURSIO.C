#include<stdio.h>
#include<conio.h>
int fact(int n)
{
   if(n==0 || n==1)
   {
      return 1;
   }
   else
   {
      return n*fact(n-1);
   }
}
int fact(int);
void main()
{
   int n,f;
   clrscr();
   printf("Enter the Number:");
   scanf("%d",&n);
   f=fact(n);
   printf("The Given Number Factorial is:%d",f);
   getch();
}