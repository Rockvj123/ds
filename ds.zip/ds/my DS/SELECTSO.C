#include<stdio.h>
#include<conio.h>
void main()
{
  int a[50],n,i,j,temp,pos;
  clrscr();
  printf("Enter the No.of elements:\n");
  scanf("%d",&n);
  printf("Enter the elements one by one:\n");
  for(i=0;i<n;i++)
    scanf("%d",&a[i]);
  for(i=0;i<n-1;i++)
  {
    pos=i;
    for(j=i+1;j<n;j++)
    {
      if(a[pos]>a[j])
	pos=j;
    }
    temp=a[pos];
    a[pos]=a[i];
    a[i]=temp;
  }


  printf("sorted elements:\n");
  for(i=0;i<n;i++)
    printf("%d\n",a[i]);
  getch();
}
