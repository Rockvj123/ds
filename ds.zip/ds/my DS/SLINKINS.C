#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
  int data;
  struct node*next;
};
struct node*addpos(struct node*head,int d,int p)
{
  struct node *ptr=head;
  struct node *temp=malloc(sizeof(struct node));
  temp->data=d;
  temp->next=NULL;
  if(p==1)
  {
    temp->next=head;
    head=temp;
  }
  else
  {
    p--;
    while(p!=1)
    {
      ptr=ptr->next;
      p--;
    }
    temp->next=ptr->next;
    ptr->next=temp;
  }
  return head;
}
void main()
{
  struct node*head=malloc(sizeof(struct node));
  struct node*second=malloc(sizeof(struct node));
  struct node*third=malloc(sizeof(struct node));
  struct node*ptr=head;
  int pos,data;
  clrscr();
  head->data=10;
  second->data=20;
  third->data=30;
  head->next=second;
  second->next=third;
  third->next=NULL;
  printf(":) SingleLL Any Position Insertion :(\n");
  printf("*************************************\n");
  printf("Enter Your Position:");
  scanf("%d",&pos);
  if(pos<=4)
  {
    printf("Enter your Data:");
    scanf("%d",&data);
    ptr=addpos(head,data,pos);
    while(ptr!=NULL)
    {
      printf("%d\n",ptr->data);
      ptr=ptr->next;
    }
  }
  else
  {
    printf("Invalid Position!");
  }


  getch();
}
