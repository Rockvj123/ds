#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
  int coeff,pow;
  struct node*next;
};
struct node*print(struct node*temp)
{
  if(temp==NULL)
  {
    printf("*** The List Is Empty ***\n");
  }
  while(temp->next!=NULL)
  {
    printf("%dX^%d+",temp->coeff,temp->pow);
    temp=temp->next;
  }
  printf("%dx^%d",temp->coeff,temp->pow);
  return temp;
}
struct node*insert(struct node*head,int co,int power)
{
  struct node*temp;
  struct node*newnode=malloc(sizeof(struct node));
  newnode->coeff=co;
  newnode->pow=power;
  newnode->next=NULL;
  if(head==NULL || power>head->pow)
  {
    newnode->next=head;
    head=newnode;
  }
  else
  {
    temp=head;
    while(temp->next!=NULL && temp->next->pow>=power)
    {
      temp=temp->next;
    }
    newnode->next=temp->next;
    temp->next=newnode;
  }
  return head;
}
struct node*create(struct node*head)
{
  int n,i,coeff,pow;
  printf("Enter The Number Of Terms:");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
    printf("Enter The Coefficient Of %d Terms:",i+1);
    scanf("%d",&coeff);
    printf("Enter Your Power Of %d Terms:",i+1);
    scanf("%d",&pow);
    head=insert(head,coeff,pow);
  }
  return head;
}
void polyadd(struct node*head,struct node*head2)
{
  struct node*ptr=head;
  struct node*ptr2=head2;
  struct node*head3=NULL;
  while(ptr!=NULL && ptr2!=NULL)
  {
    if(ptr->pow==ptr2->pow)
    {
      head3=insert(head3,(ptr->coeff)+(ptr2->coeff),ptr->pow);
      ptr=ptr->next;
      ptr2=ptr2->next;
    }
    else if(ptr2->pow > ptr->pow)
    {
      head3=insert(head3,ptr2->coeff,ptr2->pow);
      ptr2=ptr2->next;
    }
    else if(ptr->pow > ptr2->pow)
    {
      head3=insert(head3,ptr->coeff,ptr->pow);
      ptr=ptr->next;
    }
  }
  while(ptr!=NULL)
  {
    head3=insert(head3,ptr->coeff,ptr->pow);
    ptr=ptr->next;
  }
  while(ptr2!=NULL)
  {
    head3=insert(head3,ptr2->coeff,ptr2->pow);
    ptr2=ptr2->next;
  }
  printf("Add Polynomial Is :");
  head=print(head3);
}
void main()
{
  struct node*head=NULL;
  struct node*head2=NULL;
  clrscr();
  printf("\t\t\t*** First Polynomial ***\n");
  head=create(head);
  printf("\t\t\t*** Second Polynomial ***\n");
  head2=create(head2);
  polyadd(head,head2);
  getch();
}