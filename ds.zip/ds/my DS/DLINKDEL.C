#include<stdio.h>
#include<conio.h>
#include<stdio.h>
struct node
{
  int data;
  struct node*prev,*next;
};
struct node*delpos(struct node*head,int p)
{
  if(head == NULL)
    printf("! List is Empty !");
  else
  {
    struct node*ptr,*temp;
    int i;
    if(p == 1)
    {
      head=ptr->next;
      free(ptr);
      return head;
    }
    for(i=1;i<p-1;i++)
    {
      ptr=ptr->next;
    }
    temp=ptr->next;
    ptr->next=temp->next;
    temp->next=ptr;
    free(temp);
  }
  return head;
}
void main()
{
  struct node*head=malloc(sizeof(struct node));
  struct node*second=malloc(sizeof(struct node));
  struct node*third=malloc(sizeof(struct node));
  struct node*ptr=head;
  int p;
  clrscr();
  head->data=100;
  second->data=200;
  third->data=300;
  head->prev=NULL;
  second->prev=head;
  third->prev=second;
  head->next=second;
  second->next=third;
  third->next=NULL;
  printf("Enter the Position:");
  scanf("%d",&p);
  ptr=delpos(head,p);
  while(ptr!=NULL)
  {
    printf("%d\n",ptr->data);
    ptr=ptr->next;
  }
  getch();
}