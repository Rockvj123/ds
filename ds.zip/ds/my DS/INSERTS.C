#include<stdio.h>
#include<conio.h>
void main()
{
int a[20],i,n,ele,pos;
clrscr();
printf("Enter the array size:");
scanf("%d",&n);
printf("Array Elements:\n");
for(i=0;i<n;i++)
{
   scanf("%d",&a[i]);
}
printf("Enter new Elements:");
scanf("%d",&ele);
printf("Enter Position:");
scanf("%d",&pos);
n=n+1;
for(i=n-1;i>=pos;i--)
{
   a[i]=a[i-1];
}
a[pos]=ele;
printf("After Insertion:\n");
for(i=0;i<n;i++)
{
   printf("%d\n",a[i]);
}
getch();
}


