#include<stdio.h>
#include<conio.h>
void main()
{
int r;
int n;
int s=0;
clrscr();
scanf("%d",&n);
while(n!=0)
{
r=n%10;
s=(s*10)+r;
n=n/10;
}
printf("the reversal number 424 is %d",s);
getch();
}