#include<stdio.h>
#include<conio.h>
void main()
{
int a[20],i,n,pos;
clrscr();
printf("Enter the array size:");
scanf("%d",&n);
printf("Array Elements:\n");
for(i=0;i<n;i++)
 {
   scanf("%d",&a[i]);
 }
printf("Enter the Position:\n");
scanf("%d",&pos);
if(pos>=n)
 {
   printf("Deletion not possible");
 }
else
 {
for(i=pos;i<n-1;i++)
   {
      a[i]=a[i+1];
   }
      n=n-1;
}
      printf("Array After Deletion \n");
      for(i=0;i<n;i++)
    {
       printf("%d\t",a[i]);
    }
  getch();
}
