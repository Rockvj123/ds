#include<stdio.h>
#include<conio.h>
#define MAX 6
void ins();
void del();
void disp();
int queue[MAX];
int front=-1;
int rear=-1;
void main()
{
   int ch;
   clrscr();
   printf(":) Linear Queue Implementation Using Array :(\n");
   while(1)
   {
      printf("*** Queue Operation ***\n 1.Insertion\n 2.Deletion\n 3.Display\n 4.Exit\n");

      printf("--- Enter Your Choice ---:");
      scanf("%d",&ch);
      switch(ch)
      {
	 case 1:ins();break;
	 case 2:del(1);break;
	 case 3:disp();break;
	 case 4:exit();break;
	 default:
	    printf("! Wrong Choice !\n");
      }
   }
}
void ins()
{
   if(rear == MAX-1)
      printf("! Queue Overflow !\n");
   else
   {
      if(front>=-1)
      {
	 int item;
	 front=0;
	 printf("Enter Your Insert Element:\n");
	 scanf("%d",&item);
	 rear=rear+1;
	 queue[rear]=item;
      }
   }
}
void del()
{
   if(front == -1 || front>rear)
      printf("! Queue is Underflow !\n");
   else
   {
      printf("Deleted Element in Queue:%d\n",queue[front]);
      front=front+1;
   }
}
void disp()
{
   if(front == -1 || front >rear)
      printf("! Queue is Empty !\n ");
   else
   {
      int i;
      for(i=front;i<=rear;i++)
	 printf("%d\n",queue[i]);
   }
}

