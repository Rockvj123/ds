#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define size 5
int top=-1,st[size];
void push();
void pop();
void view();
void main()
{
   int ch;
   clrscr();
   printf("Stack Opeartion\n");
   while(1)
   {
      printf("1.push\n");
      printf("2.pop\n");
      printf("3.view\n");
      printf("4.exit\n");
      printf("Enter your operation:");
      scanf("%d",&ch);
      switch(ch)
      {
	 case 1:push();break;
	 case 2:pop();break;
	 case 3:view();break;
	 case 4:exit(0);break;
	 default:
	    printf("Invalid Operation");
      }
   }
}
   void push()
   {
      int n;
      if(top == size-1)
      {
	 printf("Stack full (or) Overflow");
      }
      else
      {
	 printf("Enter the Element to be Inserted:");
	 scanf("%d", &n);
	 top=top+1;
	 st[top]=n;
      }
   }
   void pop()
   {
      if(top == -1)
	 printf("Stack Empty (or) Underflow");
      else
      {
	 printf("Poped Element is:%d",st[top]);
	 top=top-1;
      }
   }
   void view()
   {
      int i;
      if(top == -1)
	 printf("No Element in Stack");
      else
      {
	 for(i=top;i>=0;i--)
	 {
	    printf("%d\n",st[i]);
	 }
      }
   }
