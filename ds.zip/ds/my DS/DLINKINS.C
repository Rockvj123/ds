#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
  int data;
  struct node*prev,*next;
};
struct node*addpos(struct node*head,int d,int p)
{
  int i;
  struct node *ptr=head;
  struct node *temp=malloc(sizeof(struct node));
  temp->data=d;
  temp->prev=NULL;
  temp->next=NULL;
  if(p==1)
  {
    ptr->next=head;
    head->prev=ptr;
    head=ptr;
    return head;
  }
  for (i=1;i<p-1;i++)
  {
    ptr=ptr->next;
  }
  temp->next=ptr->next;
  ptr->next=temp;
  temp->prev=ptr;
  ptr->next=temp;
  return head;
}
void main()
{
  struct node*head=malloc(sizeof(struct node));
  struct node*second=malloc(sizeof(struct node));
  struct node*third=malloc(sizeof(struct node));
  struct node*ptr=head;
  int p,data1;
  clrscr();
  head->data=100;
  second->data=200;
  third->data=300;
  head->prev=NULL;
  second->prev=head;
  third->prev=second;
  head->next=second;
  second->next=third;
  third->next=NULL;
  printf("Enter the Position:");
  scanf("%d",&p);
  printf("Enter the Data:");
  scanf("%d",&data1);
  ptr=addpos(head,data1,p);
  while(ptr!=NULL)
  {
    printf("%d\n",ptr->data);
    ptr=ptr->next;
  }
  getch();
}

