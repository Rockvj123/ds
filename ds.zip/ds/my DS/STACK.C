#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int top=-1,st[100];
void push();
void pop();
void view();
void main()
{
   int ch;
   clrscr();
   printf("Stack Opeartion");
   while(1)
   {
      printf("1.push\n");
      printf("2.pop\n");
      printf("3.view\n");
      printf("4.exit\n");
      printf("Enter your operation:");
      scanf("%d",&ch);
      switch(ch)
      {
	 case1:push();break;
	 case2:pop();break;
	 case3:view();break;
	 case4:exit();break;
	 default:
	    printf("Invalid Operation");
      }
      getch();
   }
   void push()
   {
      int n;
      if(top == 100-1)
	 printf("Stack full (or) Overflow");
      else
      {
	 printf("Enter the Element to be Inserted:");
	 scanf("%d", &n);
	 top=top+1;
	 st[top]=u;
      }
   }
   void pop()
   {
      if(top == -1)
	 printf("Stack Empty (or) Underflow");
      else
      {
	 printf("Poped Element is:%d",st(top));
	 top=top-1;
      }
   }
   void view()
   {
      int i ;
      if(top == -1)
	 printf("No Element in Stack");
      else
      {
	 for(i=top;i>=0;i--)
	 {
	    printf("%d\n",st[i]);
	 }
      }
   }
}