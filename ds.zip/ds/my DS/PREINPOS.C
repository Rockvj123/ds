#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
  int data;
  struct node *left,*right;
};
struct node*create(char d)
{
  struct node*temp=malloc(sizeof(struct node));
  temp->data=d;
  temp->left=NULL;
  temp->right=NULL;
  return temp;
}
void inorder(struct node*root)
{
  if(root!=NULL)
  {
    inorder(root->left);
    printf("%c",root->data);
    inorder(root->right);
  }
}
void preorder(struct node*root)
{
  if(root!=NULL)
  {
    printf("%c",root->data);
    preorder(root->left);
    preorder(root->right);
  }
}
void postorder(struct node*root)
{
  if(root!=NULL)
  {
    postorder(root->left);
    postorder(root->right);
    printf("%c",root->data);
  }
}
void main()
{
  struct node*root;
  clrscr();
  root=create('A');
  root->left=create('B');
  root->right=create('C');
  root->left->left=create('D');
  root->left->right=create('E');
  root->right->left=create('F');
  root->right->right=create('G');
  printf("\n\t\t\t\t****Tree Traversal**** \n");
  printf("\n\t\t\t\t---------------------- \n");
  printf("\n Inorder Traversal:");
  inorder(root);
  printf("\n Preorder Traversal:");
  preorder(root);
  printf("\n Postorder Traversal:");
  postorder(root);
  getch();
}