#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
  int data;
  struct node*next;
};
struct node*search(struct node*head,int ele)
{
  struct node*temp,*ptr=head;
  int newvalue,flag=0;
  do
  {
    if(temp->data==ele)
    {
      printf("*** Element found ***\n");
      printf("Enter Your New Value:");
      scanf("%d",&newvalue);
      temp->data=newvalue;
      flag=1;
    }
    temp=temp->next;
  }
  while(temp!=NULL);
  if(flag==0)
  {
    printf("!Element Not Found In Any Location! \n");
  }
  printf("*** After Searching & Modification ***\n");
  while(ptr!=NULL)
  {
    printf("%d\n",ptr->data);
    ptr=ptr->next;
  }
  return head;
}
void main()
{
  struct node*head=malloc(sizeof(struct node));
  struct node*second=malloc(sizeof(struct node));
  struct node*third=malloc(sizeof(struct node));
  struct node*ptr=head;
  int ele;
  clrscr();
  head->data=10;
  second->data=20;
  third->data=30;
  head->next=second;
  second->next=third;
  third->next=NULL;
  printf("---Before Searching & Modification ---\n");
  while(ptr!=NULL)
  {
    printf("%d\n",ptr->data);
    ptr=ptr->next;
  }
  printf("===Enter Your Searching Element=== :");
  scanf("%d",&ele);
  head=search(head,ele);
  getch();
}