#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int coefficent,power;
	struct node * next;
};
struct node * print(struct node * temp)
{
	if(temp == NULL)
	{
		printf("\n !!! LIST IS EMPTY !!! ");
	}
	while(temp -> next != NULL)
	{
		printf(" %d X ^ %d + ",temp -> coefficent,temp -> power);
		temp = temp -> next;
	}
	printf(" %d x ^ %d ",temp -> coefficent,temp -> power);
	return temp;
}
struct node * insert(struct node * head,int co,int pow)
{
	struct node * temp;
	struct node * newnode = malloc(sizeof(struct node));
	newnode -> coefficent = co;
	newnode -> power = pow;
	newnode -> next  = NULL;
	if(head == NULL || pow > head -> power)
	{
		 newnode -> next = head;
		 head = newnode;
	}
	else
	{
		temp = head;
		while(temp -> next != NULL && temp -> next -> power >= pow)
		{
			temp = temp -> next;
		}
		newnode -> next = temp -> next;
		temp -> next = newnode;
	}
	return head;
}
struct node * create(struct node * head)
{
	int n,i,coefficent,power;
	printf("\n Enter The Number Of Terms :");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		 printf("\n Enter The Coefficient Of %d Terms... :",i+1);
		 scanf("%d",&coefficent);
		 printf("\n Enter Your Power Of      %d Terms... :",i+1);
		 scanf("%d",&power);
		 head = insert(head,coefficent,power);
	}
	return head;
}
void polyadd(struct node * head,struct node * head2)
{
	struct node * ptr   = head;
	struct node * ptr2  = head2;
	struct node * head3 = NULL;
	while(ptr != NULL && ptr2 != NULL)
	{
		if(ptr -> power == ptr2 -> power)
		{
			head3 = insert(head3,(ptr -> coefficent) + (ptr2 -> coefficent),ptr -> power);
			ptr  = ptr  -> next;
			ptr2 = ptr2 -> next;
		}
		else if(ptr2 -> power > ptr -> power)
		{
			head3 = insert(head3,ptr2 -> coefficent,ptr2 -> power);
			ptr2  = ptr2 -> next;
		}
		else if(ptr -> power > ptr2 -> power)
		{
			head3 = insert(head3,ptr -> coefficent,ptr -> power);
			ptr = ptr -> next;
		}
	}
	while(ptr != NULL)
	{
		head3 = insert(head3,ptr -> coefficent,ptr -> power);
		ptr   = ptr -> next;
	}
	while(ptr2 != NULL)
	{
		head3 = insert(head3,ptr2 -> coefficent,ptr2 -> power);
		ptr2  = ptr2 -> next;
	}
	printf("\n Add Polynomial is :");
	head = print(head3);
}
void main()
{
	struct node * head  = NULL;
	struct node * head2 = NULL;
	clrscr();
	printf("\t ********************* \n");
	printf("\t POLYNOMIAL EXPERSSION \n");
	printf("\t ********************* \n");
	printf("\t\t ****************** \n");
	printf("\t\t  First Polynomial  \n");
	printf("\t\t ****************** \n");
	head = create(head);
	printf("\t\t ******************* \n");
	printf("\t\t  Second Polynomial  \n");
	printf("\t\t ******************* \n");
	head2 = create(head2);
	polyadd(head,head2);
	getch();
}