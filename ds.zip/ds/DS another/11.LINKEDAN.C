#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node * next;
};

void display(struct node * n)
{
	while(n != NULL)
	{
		printf("\t[%d]",n -> data);
		n = n -> next;
	}
}
struct node * addpos(struct node * head,int d,int pos)
{
	struct node * ptr  = head;
	struct node * temp = malloc(sizeof(struct node));
	temp -> data = d;
	temp -> next = NULL;
	pos--;
	while(pos != 1)
	{
		ptr = ptr -> next;
		pos--;
	}
	temp -> next = ptr -> next;
	ptr -> next = temp;
	return head;
}
void main()
{
	struct node * head   = malloc(sizeof(struct node));
	struct node * second = malloc(sizeof(struct node));
	struct node * third  = malloc(sizeof(struct node));
	int data,pos;
	clrscr();
	printf("\t\t *************************** \n");
	printf("\t\t LINKED LIST AT ANY POSITION \n");
	printf("\t\t *************************** \n");
	printf("\n Enter The Head Node   :");
	scanf("%d",&head -> data);
	printf("\n Enter The Second Node :");
	scanf("%d",&second -> data);
	printf("\n Enter The Third Node  :");
	scanf("%d",&third -> data);
	printf("\n Enter The Element :");
	scanf("%d",&data);
	printf("\n Enter The Position :");
	scanf("%d",&pos);
	head   -> data = 10;
	second -> data = 20;
	third  -> data = 30;
	head   -> next = second;
	second -> next = third;
	third  -> next = NULL;
	head = addpos(head,data,pos);
	display(head);
	getch();
}