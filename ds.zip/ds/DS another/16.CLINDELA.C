#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node * next;
};

void display(struct node * tail)
{
	struct node * ptr = tail -> next;
	do
	{
		printf("\t[%d]",ptr -> data);
		ptr = ptr -> next;
	}
	while(ptr != tail -> next);
}
struct node * delpos(struct node * tail,int p)
{
	struct node * ptr  = tail;
	struct node * temp;
	if(tail == NULL)
	{
		printf("\n !!! CIRCULARQUEUE IS EMPTY !!!");
	}
	else
	{
		int i;
		if(p == 1)
		{
			tail = ptr -> next;
			free(ptr);
			return tail;
		}
		for(i=1;i < p;i++)
		{
			ptr = ptr -> next;
		}
		temp = ptr -> next;
		ptr  -> next = temp -> next;
		free(temp);
	}
	return tail;
}
void main()
{
	struct node * head   = malloc(sizeof(struct node));
	struct node * second = malloc(sizeof(struct node));
	struct node * tail   = malloc(sizeof(struct node));
	int pos;
	clrscr();
	printf("\t\t ************************************ \n");
	printf("\t\t CIRCULAR LINKED LIST AT ANY POSITION \n");
	printf("\t\t ************************************ \n");
	printf("\n Enter The Head node   :");
	scanf("%d",&head -> data);
	printf("\n Enter The second node :");
	scanf("%d",&second -> data);
	printf("\n Enter The tail node   :");
	scanf("%d",&tail -> data);
	printf("\n Enter The Position    :");
	scanf("%d",&pos);
	head   -> next = second;
	second -> next = tail;
	tail   -> next = head;
	tail = delpos(tail,pos);
	display(tail);
	getch();
}