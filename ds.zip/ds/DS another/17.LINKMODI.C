#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node * next;
};
struct node * search(struct node * head,int ele)
{
	struct node * ptr = head;
	struct node * temp;
	int newvalue,flag = 0;
	do
	{
		if(temp -> data == ele)
		{
			printf("\n ELEMENT IS FOUND \n");
			printf("\n Enter Your New Value:");
			scanf("%d",&newvalue);
			temp -> data = newvalue;
			flag = 1;
		}
		temp = temp -> next;
	}
	while(temp != NULL);
	if(flag == 0)
	{
		printf("\n !!! ELEMENT NOT FOUND !!! \n");
	}
	printf("\t ************************* \n");
	printf("\t After The Modification Is \n");
	printf("\t ************************* \n");
	while(ptr != NULL)
	{
		printf("\t[%d]",ptr -> data);
		ptr = ptr -> next;
	}
	return head;
}
void main()
{
	struct node * head   = malloc(sizeof(struct node));
	struct node * second = malloc(sizeof(struct node));
	struct node * third  = malloc(sizeof(struct node));
	struct node * ptr = head;
	int ele;
	clrscr();
	printf("\t ******************************** \n");
	printf("\t SINGLEY LINKED LIST MODIFICATION \n");
	printf("\t ******************************** \n");
	printf("\n Enter The Head Node   :");
	scanf("%d",& head -> data);
	printf("\n Enter The Second Node :");
	scanf("%d",& second -> data);
	printf("\n Enter The Third Node  :");
	scanf("%d",& third -> data);
	head   -> next = second;
	second -> next = third;
	third  -> next = NULL;
	printf("\t *********************** \n");
	printf("\t Before The Modification \n");
	printf("\t *********************** \n");
	while(ptr != NULL)
	{
		printf("\t[%d]",ptr -> data);
		ptr = ptr -> next;
	}
	printf("\n Enter Your Searching Element :");
	scanf("%d",&ele);
	head = search(head,ele);
	getch();
}