#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	char exp[100],st[100];
	int i,top = -1;
	clrscr();
	printf("\n Enter the Experssion :");
	scanf("%s",exp);
	for(i=0;i<strlen(exp);i++)
	{
		if(exp[i] == '{' || exp[i] == '[' || exp[i] == '(')
		{
			top = top + 1;
			st[top] = exp[i];
		}
		else if(exp[i] == '}' || exp[i] == ']' || exp[i] == ')')
		{
			if(top == - 1)
			{
				break;
			}
			if(exp[i] == '}' && st[top] == '{' ||
			   exp[i] == ']' && st[top] == '[' ||
			   exp[i] == ')' && st[top] == '(')
			{
				top = top -1;
			}
			else
			{
				break;
			}
		}


	}
	if(i == strlen(exp) && top == -1)
	{
		printf("\n This Experssion Is BALANCED");
	}
	else
	{
		printf("\n This Experssion Is UN-BALANCED");
	}
	getch();
}

