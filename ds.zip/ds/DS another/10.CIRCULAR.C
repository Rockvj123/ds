#include<stdio.h>
#include<conio.h>
#define MAX 50

int cqueue[MAX];
int front = -1,rear = -1;

void ins();
void del();
void dis();

void main()
{
	int ch,item;
	clrscr();
	printf("\t\t ************************* \n ");
	printf("\t\t CIRCULAR QUEUE OPERATIONS \n ");
	printf("\t\t ************************* \n ");
	while(1)
	{
		printf("\n 1. INSERT ");
		printf("\n 2. DELETE ");
		printf("\n 3. DISPLAY ");
		printf("\n 4. EXIT ");
		printf("\n Enter Your Choice :");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("\n Enter Your Element :");
				scanf("%d",&item);
				ins(item);
				break;
			case 2:
				del();break;
			case 3:
				dis();break;
			case 4:
				exit(0);
			default:
				printf("\n !!! ENTER THE CORRECT CHOICE !!! ");
		}
	}
	getch();
}
void ins(int a)
{
	if((front == 0 && rear == MAX - 1) || (front == rear + 1))
	{
		printf("\n !!! QUEUE IS OVERFLOW !!! ");
		return;
	}
	if(front == -1)
	{
		front = 0;
		rear = 0;
	}
	else
	{
		if(rear == MAX - 1)
			rear = 0;
		else
			rear = rear + 1;
	}
	cqueue[rear] = a;
}
void del()
{
	if(front == -1)
	{
		printf("\n !!! QUEUE IS UNDERFLOW !!! ");
		return;
	}
	if(front == rear)
	{
		int x;
		x = cqueue[front];
		printf("\n Deleted Element is : %d\n",x);
		front = -1;
		rear = -1;
	}
	else
	{
		int x;
		if(front == MAX - 1)
		{
			x = cqueue[front];
			printf("\n Deleted Element is : %d\n",x);
			front = 0;
		}
		else
		{
			x = cqueue[front];
			printf("\n Deleted Element is : %d\n",x);
			front = front + 1;
		}
	}
}
void dis()
{
	int frontpos = front;
	int rearpos = rear;
	if(front == -1)
		printf("\n !!! QUEUE IS EMPTY !!! ");
	if(frontpos <= rearpos)
	{
		while(frontpos <= rearpos)
		{
			printf("\t[%d]",cqueue[frontpos]);
			frontpos++;
		}
	}
	else
	{
		while(frontpos <= MAX - 1)
		{
			printf("\t[%d]",cqueue[frontpos]);
			frontpos++;
		}
		frontpos = 0;
		while(frontpos <= rearpos)
		{
			printf("\t[%d]",cqueue[frontpos]);
			frontpos++;
		}
	}
}

