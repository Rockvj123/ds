#include<stdio.h>
#include<conio.h>
int max(int num1, int num2)
{
	return(num1 > num2) ? num1 : num2;
}
int max_sum(int a[], int n, int k)
{
	int max_sum = 0, i, j;
	for(i=0;i< n - k + 1;i++)
	{
		int current_sum = 0;
		for(j=0;j<k;j++)
			current_sum += a[i + j];
		max_sum = max(current_sum, max_sum);
	}
	return max_sum;
}
void main()
{
	int a[50], n, k, i;
	clrscr();
	printf("\t\t -------------- \n");
	printf("\t\t SLIDING WINDOW \n");
	printf("\t\t -------------- \n");
	printf("\n Enter The Array Size :");
	scanf("%d",&n);
	printf("\n Enter The Array Elements..\n");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	printf("\n Enter The No:of: ELements To Sliding :");
	scanf("%d",&k);
	printf("\t --------------------------- \n");
	printf("\t Current Max_Sum Is : %d\n",max_sum(a, n, k));
	printf("\t --------------------------- \n");
	getch();
}

