#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node * next;
};
struct node * search(struct node * tail,int ele)
{
	struct node * ptr = tail;
	struct node * temp;
	int newvalue,flag = 0;
	do
	{
		if(temp -> data == ele)
		{
			printf("\t\n ELEMENT FOUND \n");
			printf("\n Enter Your New Value:");
			scanf("%d",&newvalue);
			temp -> data = newvalue;
			flag = 1;
		}
		temp = temp -> next;
	}
	while(temp != tail);
	if(flag == 0)
	{
		printf("\t\n !!! ELEMENT NOT FOUND !!! \n");
	}
	printf("\t ****************** \n");
	printf("\t After Modification \n");
	printf("\t ****************** \n");
	do
	{
		printf("\t[%d]",ptr -> data);
		ptr = ptr -> next;
	}
	while(ptr != tail);
	return tail;
}
void main()
{
	struct node * tail   = malloc(sizeof(struct node));
	struct node * second = malloc(sizeof(struct node));
	struct node * third  = malloc(sizeof(struct node));
	struct node * ptr = tail;
	int ele;
	clrscr();
	printf("\t ********************************* \n ");
	printf("\t CIRCULAR LINKED LIST MODIFICATION \n ");
	printf("\t ********************************* \n ");
	printf("\n Enter The Head Node   :");
	scanf("%d",& tail -> data);
	printf("\n Enter The Second Node :");
	scanf("%d",& second -> data);
	printf("\n Enter The Third Node  :");
	scanf("%d",& third -> data);
	tail   -> next = second;
	second -> next = third;
	third  -> next = tail;
	printf("\t ******************* \n ");
	printf("\t Before Modification \n ");
	printf("\t ******************* \n ");
	do
	{
		printf("\t[%d]",ptr -> data);
		ptr = ptr -> next;
	}
	while(ptr != tail);
	printf("\n Enter Your Searching Element :");
	scanf("%d",&ele);
	tail = search(tail,ele);
	getch();
}
