#include<stdio.h>
#include<conio.h>
#define MAX 20

int queue[MAX],front = -1,rear = -1;

void ins();
void del();
void dis();

void main()
{
	int ch;
	clrscr();
	printf("\t\t **************** \n");
	printf("\t\t QUEUE OPERATIONS \n");
	printf("\t\t **************** \n");
	while(1)
	{
		printf("\n 1.INSERT");
		printf("\n 2.DELETE");
		printf("\n 3.DISPLAY");
		printf("\n 4.EXIT");
		printf("\n Enter Your Choice :");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				ins();break;
			case 2:
				del();break;
			case 3:
				dis();break;
			case 4:
				exit(0);
			default :
				printf("\n !!! Enter Correct Choice !!! \n");
		}
	}
}
void ins()
{
	int item;
	if(rear == MAX - 1)
		printf("\n !!! QUEUE IS OVERFLOW !!! \n");
	else
	{
		if(front == -1)
		{
			front = 0;
		}
		printf("\n Enter The Element To Be Inserted :");
		scanf("%d",&item);
		rear = rear + 1;
		queue[rear] = item;

	}
}
void del()
{
	if(front == -1 || front > rear )
		printf("\n !!! QUEUE IS UNDERFLOW !!! \n");
	else
	{
		printf("\n Enter the Deleted Element : %d \n",queue[front]);
		front = front + 1;
	}
}
void dis()
{
	if(front == -1)
		printf("\n !!! QUEUE IS UNDERFLOW !!! \n");
	else
	{
		int i;
		for(i=front;i<=rear;i++)
		{
			printf("\t [%d] ",queue[i]);
		}
	}
}



