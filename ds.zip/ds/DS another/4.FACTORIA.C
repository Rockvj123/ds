#include<stdio.h>
#include<conio.h>
int fact(int x){
	if(x == 1 || x == 0 || x < 0)
		return 1;
	else
		return x * fact(x-1);
}
void main(){
	 int n;
	 clrscr();
	 printf("\t\t ********* \n");
	 printf("\t\t FACTORIAL \n");
	 printf("\t\t ********* \n");
	 printf("\n Enter the Number: ");
	 scanf("%d",&n);
	 printf("\n %d != %d",n,fact(n));
	 getch();
}