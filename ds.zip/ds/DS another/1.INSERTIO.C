#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i,ele,pos,a[20];
	clrscr();
	printf("\t\t *********************** \n");
	printf("\t\t INSERTION ARRAY ELEMENT \n");
	printf("\t\t *********************** \n");
	printf("Enter the Array Size :");
	scanf("%d",&n);
	printf("Enter the Array Element :");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf(" ********************** \n");
	printf(" The Array Elements Are \n");
	printf(" ********************** \n");
	for(i=0;i<n;i++)
	{
		printf("\t [%d] => [%d] \n",i,a[i]);
	}
	printf("\n Enter the New Element :");
	scanf("%d",&ele);
	printf("\n Enter the position of Element :");
	scanf("%d",&pos);
	if(pos < n)
	{
		n = n + 1;
		for(i=n-1;i>=pos;i--)
		{
			a[i] = a[i - 1];
		}
		a[pos] = ele;
		printf("\t ************************************ \n");
		printf("\t After Insertion The Array Element is \n");
		printf("\t ************************************ \n");
		for(i=0;i<n;i++)
		{
			printf("\t [%d] => [%d] \n",i,a[i]);
		}
	}
	else
		printf("\t\n Enter The Correct Postion !!!");
	getch();
}