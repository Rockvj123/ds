#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node * next;
	struct node * prev;
};
void display(struct node * n)
{
	while(n != NULL)
	{
		printf("\t[%d]",n -> data);
		n = n -> next;
	}
}
struct node * addpos(struct node * head,int d,int pos)
{
	struct node * ptr  = head;
	struct node * temp = malloc(sizeof(struct node));
	temp -> data = d;
	temp -> prev = NULL;
	temp -> next = NULL;
	pos--;
	while(pos != 1)
	{
		ptr = ptr -> next;
		pos--;
	}
	temp -> next = ptr -> next;
	ptr  -> next = temp;
	temp -> prev = ptr;
	ptr  -> next -> prev = temp;
	return head;

}
void main()
{
	struct node * head   = malloc(sizeof(struct node));
	struct node * second = malloc(sizeof(struct node));
	struct node * third  = malloc(sizeof(struct node));
	int data,pos;
	clrscr();
	printf("\t\t ********************************* \n");
	printf("\t\t DOUBLY LINKEDLIST AT ANY POSITION \n");
	printf("\t\t ********************************* \n");
	printf("\n Enter The Head Node   :");
	scanf("%d",&head -> data);
	printf("\n Enter The Second Node :");
	scanf("%d",&second -> data);
	printf("\n Enter The Third Node  :");
	scanf("%d",&third -> data);
	printf("\n Enter The Element  :");
	scanf("%d",&data);
	printf("\n Enter The Position :");
	scanf("%d",&pos);
	head   -> prev = NULL;
	head   -> next = second;
	second -> prev = head;
	second -> next = third;
	third  -> prev = second;
	third  -> next = NULL;
	head = addpos(head,data,pos);
	display(head);
	getch();
}