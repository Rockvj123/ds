#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	char data;
	struct node *left, *right;
};
struct node * create(char d)
{
	struct node * temp = malloc(sizeof(struct node));
	temp -> data  = d;
	temp -> left  = NULL;
	temp -> right = NULL;
	return temp;
}
void preorder(struct node * root)
{
	if(root != NULL)
	{
		printf("%c",root -> data);
		preorder(root -> left);
		preorder(root -> right);
	}
}
void inorder(struct node * root)
{
	if(root != NULL)
	{
		inorder(root -> left);
		printf("%c",root -> data);
		inorder(root -> right);
	}
}
void postorder(struct node * root)
{
	if(root != NULL)
	{
		postorder(root -> left);
		postorder(root -> right);
		printf("%c",root -> data);
	}
}
void main()
{
	struct node * root;
	clrscr();
	root = create('A');
	root -> left  = create('B');
	root -> right = create('C');
	root -> left -> left   = create('D');
	root -> left -> right  = create('E');
	root -> right -> left  = create('F');
	root -> right -> right = create('G');
	printf("\t\t -------------- \n");
	printf("\t\t TREE TRAVERSAL \n");
	printf("\t\t -------------- \n");
	printf("\n ---------------------------------------------- ");
	printf("\n PREORDER  TRAVERSAL IS : ");
	preorder(root);
	printf("\n ---------------------------------------------- ");

	printf("\n ---------------------------------------------- ");
	printf("\n INORDER   TRAVERSAL IS : ");
	inorder(root);
	printf("\n ---------------------------------------------- ");

	printf("\n ---------------------------------------------- ");
	printf("\n POSTORDER TRAVERSAL IS : ");
	postorder(root);
	printf("\n ---------------------------------------------- ");
	getch();
}