#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

struct node
{
	int data,tail;
	struct node * next;
};

void display(struct node * tail)
{
	struct node * ptr = tail -> next;
	do
	{
		printf("\t[%d]",ptr -> data);
		ptr = ptr -> next;
	}
	while(ptr != tail -> next);
}
struct node * addpos(struct node * tail,int d,int pos)
{
	struct node * ptr  = tail -> next;
	struct node * temp = malloc(sizeof(struct node));
	temp -> data = d;
	temp -> next = NULL;
	pos--;
	while(pos != 1)
	{
		ptr = ptr -> next;
		pos--;
	}
	temp -> next = ptr -> next;
	ptr  -> next = temp;
	return tail;
}
void main()
{
	struct node * head   = malloc(sizeof(struct node));
	struct node * second = malloc(sizeof(struct node));
	struct node * tail   = malloc(sizeof(struct node));
	int data,pos;
	clrscr();
	printf("\t\t ************************************ \n");
	printf("\t\t CIRCULAR LINKED LIST AT ANY POSITION \n");
	printf("\t\t ************************************ \n");
	printf("\n Enter The Head node   :");
	scanf("%d",&head -> data);
	printf("\n Enter The second node :");
	scanf("%d",&second -> data);
	printf("\n Enter The tail node   :");
	scanf("%d",&tail -> data);
	printf("\n Enter The Element     :");
	scanf("%d",&data);
	printf("\n Enter The Position    :");
	scanf("%d",&pos);
	head   -> next = second;
	second -> next = tail;
	tail   -> next = head;
	head = addpos(tail,data,pos);
	display(tail);
	getch();
}