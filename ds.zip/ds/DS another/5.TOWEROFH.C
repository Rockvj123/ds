#include<stdio.h>
#include<conio.h>

void towerofhanoi(int n, char from, char to, char end)
{
	if(n == 1)
	{
		printf("\n Disk Move 1 From %c to %c \n",from,to);
		return;
	}
	towerofhanoi(n - 1, from, end, to);
	printf("\n Disk Move %d From %c to %c \n",n,from,to);
	towerofhanoi(n - 1, end, to, from);
}
void main()
{
	int n;
	clrscr();
	printf("\t\t ************** \n");
	printf("\t\t TOWER OF HANOI \n");
	printf("\t\t ************** \n");
	printf("\n Enter The No:Of:Disk :");
	scanf("%d",&n);
	towerofhanoi(n , 'A' , 'B' , 'C');
	getch();
}