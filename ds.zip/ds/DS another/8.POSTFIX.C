#include<stdio.h>
#include<conio.h>
#define MAX_SIZE 100
int stack[MAX_SIZE];
int top = -1;

int evaluate(char* exp)
{
	int i=0;
	char symbol = exp[i];
	int ope1,ope2,result;
	while(symbol != '\0')
	{
		if(symbol>='0' && symbol<='9')
		{
			int num = symbol - '0';
			push(num);
		}
		else if(is_operator(symbol))
		{
			ope2 = pop();
			ope1 = pop();
			switch(symbol)
			{
				case '+':
					result = ope1 + ope2;
					break;
				case '-':
					result = ope1 - ope2;
					break;
				case '*':
					result = ope1 * ope2;
					break;
				case '/':
					result = ope1 / ope2;
					break;
			}
			push(result);
		}
		i++;
		symbol = exp[i];
	}
	result = pop();
	return result;
}

int push(int item)
{
	if(top >= MAX_SIZE-1)
	{
		printf("\t\n !!! STACK IS OVERFLOW !!! \n");
		return ;
	}
	top++;
	stack[top] = item;
	return ;
}

int pop()
{
	int item;
	if(top<0)
	{
		printf("\t\n !!! STACK IS UNDERFLOW !!! \n");
		return -1;
	}
	item = stack[top];
	top--;
	return item;

}

int is_operator(char symbol)
{
	if((symbol == '+') || (symbol == '-') ||
	   (symbol == '*') || (symbol == '/'))
	{
		return 1;
	}
	return 0;
}

void main()
{
	char exp[100];
	int result;
	clrscr();
	printf("\t\t ******************************** \n");
	printf("\t\t EVALUATION OF POSTFIX EXPRESSION \n");
	printf("\t\t ******************************** \n");
	printf("\n Enter The Expression :");
	scanf("%s",&exp);
	result = evaluate(exp);
	printf("\n Result = %d",result);
	getch();
}


