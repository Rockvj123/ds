#include<stdio.h>
#include<conio.h>
void main()
{
	int a[50],i,n,search,flag;
	clrscr();
	printf("\t\t ************* \n");
	printf("\t\t LINEAR SEARCH \n");
	printf("\t\t ************* \n");
	printf("\n Enter The Array Size     :");
	scanf("%d",&n);
	printf("\n Enter The Array Elements :\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n Enter The Searching Element :");
	scanf("%d",&search);
	for(i=0;i<n;i++)
	{
		if(a[i] == search)
		{
			printf("\n The Element Is Found at Index %d .... ",i);
			flag = 1;
		}
	}
	if(flag < 0)
		printf("\n !!! ELEMENT NOT FOUND !!! ");
	getch();
}

