#include<stdio.h>
#include<conio.h>
#include<string.h>

int pre(char c)
{
	if(c == '^')
		return 3;
	else if(c == '/' || c == '*')
		return 2;
	else if(c == '+' || c == '-')
		return 1;
	else
		return -1;
}
void intopost(char s[])
{
	char res[100],stack[100];
	int resindex = 0,index = -1,len = strlen(s),i = 0;

	for(i=0;i<len;i++)
	{
		char c = s[i];

		if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
		  (c >= '0' && c <='9'))
		{
			res[resindex++] = c;
		}
		else if(c == '(')
			stack[++index] = c;
		else if(c == ')')
		{
			while(index >= 0 && stack[index] !='(')
			{
				res[resindex++] = stack[index--];
			}
			index--;
		}
		else
		{
			while(index >= 0 && (pre(c)) <= pre(stack[index]))
			{
				res[resindex++] = stack[index--];
			}
			stack[++index] = c;
		}
	}
	while(index >=0)
	{
		res[resindex++] = stack[index--];
	}
	res[resindex] = '\0';
	printf("\t\n **************************** \n");
	printf("\t\n %s Is The PostFix Conversion \n",res);
	printf("\t\n **************************** \n");
}
void main()
{
	char exp[100];
	clrscr();
	printf("\t\t *************************** \n");
	printf("\t\t INFIX TO POSTFIX CONVERSION \n");
	printf("\t\t *************************** \n");
	printf("\n Enter your Experssion :");
	scanf("%s",&exp);
	intopost(exp);
	getch();
}
