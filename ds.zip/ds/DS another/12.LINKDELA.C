#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node * next;
};

void display(struct node * n)
{
	while(n != NULL)
	{
		printf("\t[%d]",n -> data);
		n = n -> next;
	}
}
struct node * delpos(struct node * head,int pos)
{
	if(head == NULL)
		printf("\n !!! LIST IS EMPTY !!! ");
	else
	{
		struct node * ptr = head,* temp;
		int i;
		if(pos == 1)
		{
			head = ptr -> next;
			free(ptr);
			return head;
		}
		for(i=1;i < pos -1 && ptr != NULL;i++)
		{
			ptr = ptr -> next;
		}
		if(ptr == NULL || ptr -> next == NULL)
		{
			printf("\n !!! OUT OF RANGE !!!");
			return head;
		}
		else
		{
			temp = ptr -> next;
			ptr -> next = temp -> next;
			free(temp);
			display(head);
		}
	}
	return head;
}
void main()
{
	struct node * head   = malloc(sizeof(struct node));
	struct node * second = malloc(sizeof(struct node));
	struct node * third  = malloc(sizeof(struct node));
	int data,pos;
	clrscr();
	printf("\t\t ************************************ \n");
	printf("\t\t LINKED LIST DELETION AT ANY POSITION \n");
	printf("\t\t ************************************ \n");
	printf("\n Enter The Head Node   :");
	scanf("%d",&head -> data);
	printf("\n Enter The Second Node :");
	scanf("%d",&second -> data);
	printf("\n Enter The Third Node  :");
	scanf("%d",&third -> data);
	printf("\n Enter The Position :");
	scanf("%d",&pos);
	head   -> next = second;
	second -> next = third;
	third  -> next = NULL;
	head = delpos(head,pos);
	getch();
}
