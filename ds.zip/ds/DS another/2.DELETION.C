#include<stdio.h>
#include<conio.h>
void main()
{
	int a[20],i,pos,n;
	clrscr();
	printf("\t\t ************************** \n");
	printf("\t\t DELETING THE ARRAY ELEMENT \n");
	printf("\t\t ************************** \n");
	printf("\n Enter the array size :");
	scanf("%d",&n);
	printf("\n Enter the Array Element :");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n ******************** ");
	printf("\n The Array Element Is ");
	printf("\n ******************** ");
	for(i=0;i<n;i++)
	{
		printf("\n\t [%d] => [%d]",i,a[i]);
	}
	printf("\n\n Enter the position of element :");
	scanf("%d",&pos);
	if(pos>=n)
	{
		printf("DELETION NOT POSSIBLE");
	}
	else
	{
		for(i=pos;i<n-1;i++)
		{
			a[i] = a[i+1];
		}
		n = n - 1;
		printf("\n *********************************** ");
		printf("\n After Deletion The Array Element Is ");
		printf("\n *********************************** ");
		for(i=0;i<n;i++)
		{
			printf("\n\t [%d] => [%d]",i,a[i]);
		}
	}
	getch();
}