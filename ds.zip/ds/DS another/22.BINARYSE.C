#include<stdio.h>
#include<conio.h>
void main()
{
	int a[50],i,n,search;
	int first,last,mid;
	clrscr();
	printf("\t\t ************* \n");
	printf("\t\t BINARY SEARCH \n");
	printf("\t\t ************* \n");
	printf("\n Enter The Array Size     :");
	scanf("%d",&n);
	printf("\n Enter The Array Elements :\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n Enter The Searching Element :");
	scanf("%d",&search);
	first = 0;
	last = n - 1;
	while(first <= last)
	{
		mid = (first + last) / 2;
		if(a[mid] == search)
		{
			printf("\n %d occurs at %d ",search,mid);
			break;
		}
		else if(a[mid] < search)
		{
			first = mid + 1;
		}
		else
		{
			last = mid - 1;
			mid = (first + last) / 2;
		}
		if(first > last)
			printf("\n !!! ELEMENT NOT FOUND !!! ");
	}
	getch();
}

