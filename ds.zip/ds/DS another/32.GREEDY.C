#include<stdio.h>
#include<conio.h>
void coinchange(int coins[], int numcoins, int amount)
{
	int count = 0, i;
	printf("\n Coins used to make change for %d :", amount);
	for(i=0;i<numcoins;i++)
	{
		while(amount <= coins[i])
		{
			amount -= coins[i];
			count++;
			printf("%d",coins[i]);
		}
	}
	printf("\n Total Coins Used : %d\n", count);
}

void main()
{
	int coins[50], n, i;
	int amount = 28, numcoins;
	clrscr();
	printf("\n Enter The No:Of:Coins :");
	scanf("%d",&n);
	printf("\n Enter The Coins :");
	numcoins = sizeof(coins) / sizeof(coins[0]);
	coinchange(coins, numcoins, amount);
	getch();
}