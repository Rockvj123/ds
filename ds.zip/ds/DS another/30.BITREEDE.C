#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int key;
	struct node * left, * right;
};
void inorder(struct node * root)
{
	if(root != NULL)
	{
		inorder(root -> left);
		printf("%d ", root -> key);
		inorder(root -> right);
	}
}
struct node * create(int key)
{
	struct node * temp = malloc(sizeof(struct node));
	temp -> key  = key;
	temp -> left = temp -> right = NULL;
	return temp;
}
struct node * minvalue(struct node * node)
{
	struct node * current = node;
	while(current -> left != NULL)
		current = current -> left;
	return current;
}
struct node * deletenode(struct node * root, int key)
{
	if(root == NULL)
		return root;
	if(key < root -> key)
		root -> left  = deletenode(root -> left, key);
	else if(key > root -> key)
		root -> right = deletenode(root -> right, key);
	else
	{
		if(root -> left == NULL)
		{
			struct node * temp = root -> right;
			free(root);
			return temp;
		}

		else if(root -> right == NULL)
		{
			struct node * temp = root -> left;
			free(root);
			return temp;
		}
		else
		{
			struct node * temp = minvalue(root -> right);
			root -> key = temp -> key;
			root -> right = deletenode(root -> right,temp -> key);
		}
	}
	return root;
}
void main()
{
	int ele;
	struct node * root = NULL;
	clrscr();
	printf("\t\t --------------------------- \n");
	printf("\t\t BINARY SEARCH TREE DELETION \n");
	printf("\t\t --------------------------- \n");

	root = create(35);
	root -> left  = create(20);
	root -> right = create(58);
	root -> left  -> left  = create(10);
	root -> left  -> right = create(23);
	root -> right -> left  = create(42);
	root -> right -> right = create(64);
	printf("\n ----------------------------------------------------- \n");
	printf("  In - order before deletion: ");
	inorder(root);
	printf("\n ----------------------------------------------------- \n");

	printf("\n Enter the element to be deleted: ");
	scanf("%d",&ele);
	root = deletenode(root, ele);

	printf("\n ----------------------------------------------------- \n");
	printf("   In - order after deletion: ");
	inorder(root);
	printf("\n ----------------------------------------------------- \n");

	printf("\n");
	getch();
}
