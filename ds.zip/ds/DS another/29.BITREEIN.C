#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int key;
	struct node * left, * right;
};
void inorder(struct node * root)
{
	if(root != NULL)
	{
		inorder(root -> left);
		printf("%d\t",root -> key);
		inorder(root -> right);
	}
}
struct node * newnode(int item)
{
	struct node * temp = malloc(sizeof(struct node));
	temp -> key = item;
	return temp;
}
struct node * insert(struct node * node,int key)
{
	if(node == NULL)
		return newnode(key);
	if(key < node -> key)
		node -> left  = insert(node -> left, key);
	if(key > node -> key)
		node -> right = insert(node -> right,key);
	return node;
}
void main()
{
	int i,n,ele;
	struct node * root = NULL;
	clrscr();
	printf("\t\t ----------------------------- \n");
	printf("\t\t BINARY SEARCH TREE INSERATION \n");
	printf("\t\t ----------------------------- \n");
	printf("\n Enter The No:Of:Node :");
	scanf("%d",&n);
	printf("\n Enter The Node Elements..\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&ele);
		root = insert(root,ele);
	}
	inorder(root);
	getch();
}

