#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define size 5

int top = -1,st[size];
void push();
void pop();
void view();

void main()
{
	int ch;
	clrscr();
	printf("\t\t ************** \n");
	printf("\t\t STACK OPERTION \n");
	printf("\t\t ************** \n");
	while(1)
	{
		printf("\n 1. PUSH()");
		printf("\n 2. POP()");
		printf("\n 3. VIEW()");
		printf("\n 4. EXIT \n");
		printf("\n Enter Your Choice :");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				push();break;
			case 2:
				pop();break;
			case 3:
				view();break;
			case 4:
				exit(0);
		default:
			printf("\n INVAULID CHOICE \n");
		}
	}
	getch();
}
void push()
{
	int x;
	printf("\t **************** \n");
	printf("\t PUSH OPERTION IS \n");
	printf("\t **************** \n");
	if(top == size-1)
	{
		printf("\n STACK IS FULL !!! \n");
	}
	else
	{
		printf("\n Enter the Element To Be Inserted :");
		scanf("%d",&x);
		top = top+1;
		st[top] = x;
	}
}
void pop()
{
	printf("\t **************** \n");
	printf("\t POP OPERATION IS \n");
	printf("\t **************** \n");
	if(top == -1)
	{
		printf("\n Stack is Empty \n");
	}
	else
	{
		printf("\n Popped Element is: %d \n",st[top]);
		top = top-1;
	}
}
void view()
{
	int i;
	if(top == -1)
	{
		printf("\n No Element is Found \n");
	}
	else
	{
		for(i=top;i>=0;i--)
		{
			printf("\t [%d] => [%d] \n",i,st[i]);
		}
	}
}
